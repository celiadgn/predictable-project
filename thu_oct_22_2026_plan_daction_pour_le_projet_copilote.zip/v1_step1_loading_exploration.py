"""
Étape 1 — Chargement et exploration des données
Projet : Identification des utilisateurs de Copilote (MOD 7.2)

Ce script :
- charge train.csv et test.csv avec la méthode robuste (readlines + nb max de colonnes)
- affiche les dimensions, types, taux de NaN
- explore la distribution des navigateurs et de la variable cible 'util'
- explore la longueur des séquences (nombre d'actions non-NaN par session)
- identifie des valeurs aberrantes potentielles (sessions trop courtes / trop longues)
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# ---------------------------------------------------------------------------
# 1. Chargement des données
# ---------------------------------------------------------------------------

def read_ds(ds_name: str, data_dir: str = "data") -> pd.DataFrame:
    """
    Charge un fichier CSV de traces (train ou test) sans en-tête fixe,
    en déterminant dynamiquement le nombre maximal de colonnes nécessaires.

    Parameters
    ----------
    ds_name : str
        "train" ou "test" (le fichier correspondant doit être nommé {ds_name}.csv)
    data_dir : str
        dossier contenant les fichiers csv

    Returns
    -------
    pd.DataFrame
    """
    path = f"{data_dir}/{ds_name}.csv"
    with open(path, encoding="utf-8") as f:
        max_actions = max(len(str(line).split(",")) for line in f.readlines())
        f.seek(0)
        _names = ["util", "navigateur"] if "train" in ds_name else ["navigateur"]
        _names.extend(range(max_actions - len(_names)))
        return pd.read_csv(f, names=_names, dtype=str)


def load_datasets(data_dir: str = "data"):
    """Charge train et test et affiche leurs dimensions."""
    df_train = read_ds("train", data_dir)
    df_test = read_ds("test", data_dir)
    print(f"[INFO] Dimensions train : {df_train.shape}")
    print(f"[INFO] Dimensions test  : {df_test.shape}")
    return df_train, df_test


# ---------------------------------------------------------------------------
# 2. Exploration générale : NaN, types
# ---------------------------------------------------------------------------

def explore_nan_ratio(df: pd.DataFrame, name: str = "dataset"):
    """Affiche le taux global de valeurs manquantes et un résumé par colonne."""
    nan_ratio_global = df.isna().mean().mean()
    print(f"[INFO] Taux de NaN global dans {name} : {nan_ratio_global:.2%}")

    nan_by_col = df.isna().mean()
    print(f"[INFO] Colonnes avec 0% de NaN dans {name} : "
          f"{(nan_by_col == 0).sum()} / {len(nan_by_col)}")
    return nan_by_col


# ---------------------------------------------------------------------------
# 3. Distribution du navigateur
# ---------------------------------------------------------------------------

def browsers_per_player(df: pd.DataFrame) -> pd.DataFrame:
    """
    Retourne, pour chaque utilisateur (en ligne), le nombre de sessions
    effectuées avec chaque navigateur (en colonne).
    Nécessite une colonne 'util' (donc applicable uniquement sur train).
    """
    return pd.crosstab(df["util"], df["navigateur"])


def plot_browser_distribution(df: pd.DataFrame, title: str = "Navigateur"):
    """Affiche un histogramme de la distribution globale des navigateurs."""
    counts = df["navigateur"].value_counts()
    plt.figure(figsize=(6, 4))
    counts.plot(kind="bar")
    plt.title(title)
    plt.ylabel("Nombre de sessions")
    plt.xticks(rotation=30, ha="right")
    plt.tight_layout()
    plt.show()
    return counts


# ---------------------------------------------------------------------------
# 4. Distribution de la variable cible (util)
# ---------------------------------------------------------------------------

def get_Y_stats(df: pd.DataFrame) -> pd.Series:
    """
    Retourne le nombre de sessions par utilisateur (variable cible 'util'),
    trié par ordre décroissant. Permet de repérer un éventuel déséquilibre
    de classes.
    """
    stats = df["util"].value_counts()
    print(f"[INFO] Nombre d'utilisateurs uniques : {df['util'].nunique()}")
    print(f"[INFO] Nombre moyen de sessions / utilisateur : {stats.mean():.2f}")
    print(f"[INFO] Min / Max sessions par utilisateur : {stats.min()} / {stats.max()}")
    return stats


def plot_Y_distribution(stats: pd.Series):
    plt.figure(figsize=(10, 4))
    stats.plot(kind="bar")
    plt.title("Nombre de sessions par utilisateur")
    plt.xlabel("Utilisateur")
    plt.ylabel("Nombre de sessions")
    plt.xticks([])  # trop d'utilisateurs pour afficher les labels proprement
    plt.tight_layout()
    plt.show()


# ---------------------------------------------------------------------------
# 5. Longueur des séquences (nombre d'actions non-NaN par session)
# ---------------------------------------------------------------------------

def session_length(df: pd.DataFrame, action_start_col: int = 0) -> pd.Series:
    """
    Calcule, pour chaque session (ligne), le nombre de cellules non-NaN
    parmi les colonnes d'actions (en excluant 'util' et 'navigateur').
    """
    action_cols = [c for c in df.columns if isinstance(c, int) and c >= action_start_col]
    return df[action_cols].notna().sum(axis=1)


def plot_session_length(lengths: pd.Series, title: str = "Longueur des sessions"):
    plt.figure(figsize=(6, 4))
    lengths.plot(kind="hist", bins=50)
    plt.title(title)
    plt.xlabel("Nombre d'actions (dont marqueurs temporels tXX)")
    plt.tight_layout()
    plt.show()


# ---------------------------------------------------------------------------
# 6. Détection de valeurs aberrantes (sessions extrêmes)
# ---------------------------------------------------------------------------

def detect_outlier_sessions(lengths: pd.Series, low_q: float = 0.01, high_q: float = 0.99):
    """
    Retourne les index des sessions dont la longueur est en dehors
    des quantiles [low_q, high_q], considérées comme potentiels outliers.
    """
    low_bound = lengths.quantile(low_q)
    high_bound = lengths.quantile(high_q)
    outliers = lengths[(lengths < low_bound) | (lengths > high_bound)]
    print(f"[INFO] Bornes retenues : [{low_bound:.0f}, {high_bound:.0f}] actions")
    print(f"[INFO] Nombre de sessions considérées comme outliers : {len(outliers)}")
    return outliers.index


# ---------------------------------------------------------------------------
# Exécution principale (exemple d'utilisation)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # 1. Chargement
    features_train, features_test = load_datasets(data_dir="data")

    # 2. NaN
    explore_nan_ratio(features_train, "train")
    explore_nan_ratio(features_test, "test")

    # 3. Navigateur
    print(features_train["navigateur"].unique())
    bpp = browsers_per_player(features_train)
    print(bpp.head())
    plot_browser_distribution(features_train, "Navigateur - Train")

    # 4. Distribution de la cible
    y_stats = get_Y_stats(features_train)
    plot_Y_distribution(y_stats)

    # 5. Longueur des sessions
    lengths_train = session_length(features_train)
    plot_session_length(lengths_train, "Longueur des sessions - Train")

    # 6. Outliers
    outlier_idx = detect_outlier_sessions(lengths_train)
    print(features_train.loc[outlier_idx, ["util", "navigateur"]].head())

    # Optionnel : suppression des outliers (à décider selon l'analyse)
    # features_train_clean = features_train.drop(index=outlier_idx)