"""
Étape 2 — Parsing des actions brutes
Projet : Identification des utilisateurs de Copilote (MOD 7.2)

Format d'une action brute, d'après data_description.txt :
    NomAction(ecran)<conf_ecran>$chaine$1

- NomAction           : toujours présent, ex. "Création d'un écran"
- (ecran)             : optionnel, écran visité, ex. (infologic.crm.modules...)
- <conf_ecran>        : optionnel, configuration de l'écran, ex. <ACCUEIL_INST>
- $chaine$            : optionnel, regroupement logique de la fiche, ex. $GP$
- suffixe "1"         : optionnel, indique que l'utilisateur est en modification
- "tXX"               : marqueur temporel (fenêtre en secondes), à traiter à part,
                         ce n'est PAS une action utilisateur.

Ce script fournit :
- une fonction de détection des marqueurs temporels (tXX)
- une fonction de parsing complet d'une action en ses composantes
- une fonction d'application du parsing sur tout un DataFrame de sessions
  (une ligne = une session, colonnes d'actions en largeur)
- la liste des types d'actions uniques (pour vérification / feature engineering)
"""

import re
import pandas as pd
from collections import Counter

# ---------------------------------------------------------------------------
# Regex pour extraire les composantes d'une action
# ---------------------------------------------------------------------------

PATTERN_TEMPS = re.compile(r"^t\d+$")                 # ex: "t5", "t10", "t125"
PATTERN_ECRAN = re.compile(r"\((.*?)\)")              # ex: (infologic.crm...)
PATTERN_CONF_ECRAN = re.compile(r"<(.*?)>")           # ex: <ACCUEIL_INST>
PATTERN_CHAINE = re.compile(r"\$(.*?)\$")             # ex: $GP$
PATTERN_MODIF = re.compile(r"1$")                     # suffixe de modification


def is_temps(value) -> bool:
    """Retourne True si la valeur est un marqueur temporel du type tXX."""
    if pd.isna(value):
        return False
    return bool(PATTERN_TEMPS.match(str(value).strip()))


def extract_temps_seconds(value: str) -> int:
    """Extrait le nombre de secondes d'un marqueur temporel 'tXX' -> XX (int)."""
    return int(str(value).strip()[1:])


def filter_action_name(value: str) -> str:
    """
    Retourne uniquement le nom de l'action, en retirant écran, conf_ecran,
    chaine et suffixe de modification.
    Reprend et généralise la fonction fournie dans le notebook d'indications.
    """
    for delim in ["(", "<", "$"]:
        if delim in value:
            idx = value.index(delim)
            value = value[:idx]
    # retire le suffixe "1" de modification seulement s'il est collé à la fin
    # (on ne veut pas tronquer un nom d'action qui finirait légitimement par un chiffre)
    if value.endswith("1") and not value[:-1].strip().isdigit():
        # heuristique : le suffixe de modification apparaît juste après un nom d'action connu
        # on le retire prudemment seulement dans parse_action() ci-dessous, où le contexte
        # (avant retrait des autres délimiteurs) est plus fiable.
        pass
    return value.strip()


def parse_action(raw_value) -> dict:
    """
    Parse une action brute et retourne un dictionnaire avec ses composantes :
        {
            "is_temps": bool,
            "temps_secondes": int | None,
            "action": str | None,
            "ecran": str | None,
            "conf_ecran": str | None,
            "chaine": str | None,
            "modification": bool,
        }
    Retourne un dict "vide" (tous None/False) si raw_value est NaN.
    """
    empty = {
        "is_temps": False,
        "temps_secondes": None,
        "action": None,
        "ecran": None,
        "conf_ecran": None,
        "chaine": None,
        "modification": False,
    }

    if pd.isna(raw_value):
        return empty

    value = str(raw_value).strip()

    # Cas 1 : marqueur temporel
    if is_temps(value):
        empty["is_temps"] = True
        empty["temps_secondes"] = extract_temps_seconds(value)
        return empty

    # Cas 2 : action utilisateur
    ecran_match = PATTERN_ECRAN.search(value)
    conf_match = PATTERN_CONF_ECRAN.search(value)
    chaine_match = PATTERN_CHAINE.search(value)

    # Détection du suffixe de modification : "1" en toute fin de chaîne,
    # après tous les autres éléments (parenthèses/chevrons/dollars fermés).
    modification = value.endswith("1") and not value.endswith("$1$")
    value_wo_modif = value[:-1] if modification else value

    # Nom de l'action = tout ce qui précède le premier délimiteur "(", "<" ou "$"
    action_name = value_wo_modif
    for delim in ["(", "<", "$"]:
        if delim in action_name:
            action_name = action_name[: action_name.index(delim)]
    action_name = action_name.strip()

    return {
        "is_temps": False,
        "temps_secondes": None,
        "action": action_name if action_name else None,
        "ecran": ecran_match.group(1) if ecran_match else None,
        "conf_ecran": conf_match.group(1) if conf_match else None,
        "chaine": chaine_match.group(1) if chaine_match else None,
        "modification": modification,
    }


# ---------------------------------------------------------------------------
# Application du parsing à une session complète (une ligne du DataFrame)
# ---------------------------------------------------------------------------

def parse_session(row: pd.Series, action_cols) -> list:
    """
    Parse toutes les actions d'une session (une ligne du DataFrame) et
    retourne la liste des dictionnaires de parsing (un par cellule non-NaN).
    """
    parsed = []
    for col in action_cols:
        raw_value = row[col]
        if pd.isna(raw_value):
            continue
        parsed.append(parse_action(raw_value))
    return parsed


def get_action_columns(df: pd.DataFrame):
    """Retourne la liste des colonnes d'actions (colonnes entières, hors util/navigateur)."""
    return [c for c in df.columns if isinstance(c, int)]


# ---------------------------------------------------------------------------
# Inventaire des types d'actions uniques (utile pour vérifier le parsing
# et préparer le feature engineering de l'étape 3)
# ---------------------------------------------------------------------------

def list_unique_actions(df: pd.DataFrame, action_cols=None) -> list:
    """
    Reprend l'approche du notebook d'indications : extrait toutes les valeurs
    uniques des colonnes d'actions, filtre les marqueurs temporels, puis
    applique filter_action_name pour ne garder que le nom "nettoyé".
    """
    if action_cols is None:
        action_cols = get_action_columns(df)

    uniques = df[action_cols].stack().unique()
    filtered = sorted(set(
        filter_action_name(str(u)) for u in uniques if not is_temps(u)
    ))
    return filtered


def count_action_types(df: pd.DataFrame, action_cols=None) -> Counter:
    """
    Compte la fréquence de chaque nom d'action (nettoyé) sur l'ensemble du
    DataFrame. Utile pour repérer les actions rares vs. fréquentes.
    """
    if action_cols is None:
        action_cols = get_action_columns(df)

    counter = Counter()
    for col in action_cols:
        for val in df[col].dropna():
            if is_temps(val):
                continue
            counter[filter_action_name(str(val))] += 1
    return counter


# ---------------------------------------------------------------------------
# Exécution principale (exemple d'utilisation)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    from step1_loading_exploration import load_datasets

    features_train, features_test = load_datasets(data_dir="data")
    action_cols = get_action_columns(features_train)

    # Exemple : parser la première session du train
    example_row = features_train.iloc[0]
    parsed_example = parse_session(example_row, action_cols)
    print(f"[INFO] Nombre d'éléments parsés (session 0) : {len(parsed_example)}")
    print(parsed_example[:5])

    # Inventaire des types d'actions uniques
    unique_actions = list_unique_actions(features_train, action_cols)
    print(f"[INFO] Nombre de types d'actions distincts : {len(unique_actions)}")
    print(unique_actions)

    # Fréquence des actions (top 15)
    action_counts = count_action_types(features_train, action_cols)
    print("[INFO] Top 15 actions les plus fréquentes :")
    for name, count in action_counts.most_common(15):
        print(f"  {name:50s} {count}")